
public @interface RestController {

}
