
public @interface Autowired {

}
